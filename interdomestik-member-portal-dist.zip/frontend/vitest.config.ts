import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import path from 'node:path';

const MIGRATE_GLOB = process.env.MIGRATE_GLOB || process.env.TARGET_TEST;
const RUN_LEGACY = process.env.LEGACY_TESTS === '1';

const excludePatterns = [
  'node_modules',
  'dist',
  '**/coverage/**',
];

if (process.env.LEGACY_TESTS !== '1') {
  excludePatterns.push('src/**/__legacy_tests__/**');
  excludePatterns.push('src/**/*.legacy.test.tsx');
}

export default defineConfig({
  root: __dirname,
  plugins: [react()],
  resolve: { alias: { '@': path.resolve(__dirname, 'src') } },
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: ['src/setupTests.ts'],
    include: [
      'src/**/*.{test,spec}.{ts,tsx}',
      'src/**/__tests__/**/*.{ts,tsx}',
      ...(process.env.LEGACY_TESTS === '1'
        ? ['src/**/__legacy_tests__/**/*.{ts,tsx}', 'src/**/*.legacy.test.tsx']
        : []),
    ],
    exclude: excludePatterns,
    coverage: {
      provider: 'v8',
      reporter: ['text', 'html', 'lcov'],
      all: true, // count all source files from include
      include: ['src/**/*.{ts,tsx}'],
      exclude: [
        'src/**/__tests__/**',
        'src/**/__legacy_tests__/**',
        'src/tests/**',
        'src/test-utils.tsx',
        'src/tests/mocks.ts',
        'src/tests/**',
        'src/**/*.d.ts',
        'src/**/index.ts',
        'src/main.tsx',
        'src/App.tsx',
        'src/queryClient.ts',
        'src/firebase.ts',
        'src/config/**',
        'src/constants/**',
        'src/validation/**',
        'src/types.ts',
      ],
      thresholds: { lines: 30, statements: 30, functions: 30, branches: 15 },
    },
    restoreMocks: true,
    clearMocks: true,
  },
});
