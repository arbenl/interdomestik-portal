import path from 'path';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { visualizer } from 'rollup-plugin-visualizer';

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    react(),
    visualizer({
      filename: 'stats.html',
      open: false,
    }),
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  build: {
    rollupOptions: {
      output: {
        // NOTE: We are manually chunking vendors to analyze bundle size.
        // This is a good place to enforce bundle budgets.
        manualChunks(id) {
          if (id.includes('node_modules')) {
            if (id.includes('firebase')) return 'vendor_firebase';
            if (id.includes('@tanstack')) return 'vendor_tanstack';
            if (id.includes('react-router')) return 'vendor_router';
            if (id.includes('react')) return 'vendor_react';
          } else if (id.includes('src/features/admin')) {
            return 'feature_admin';
          } else if (id.includes('src/features/portal')) {
            return 'feature_portal';
          }
        },
      },
    },
  },
});
