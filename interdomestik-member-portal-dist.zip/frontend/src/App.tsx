import { Routes, Route, Navigate } from 'react-router-dom';
import { Suspense, lazy } from 'react';
import Layout from '@/components/Layout';
import { RoleProtectedRoute } from '@/routes/RoleProtectedRoute';

const Home = lazy(() => import('@/pages/Home'));
const MemberPortal = lazy(() => import('@/pages/MemberPortal'));
const SignIn = lazy(() => import('@/pages/SignIn'));
const SignUp = lazy(() => import('@/pages/SignUp'));
const Profile = lazy(() => import('@/pages/Profile'));
const AgentTools = lazy(() => import('@/pages/AgentTools'));
const Admin = lazy(() => import('@/pages/Admin'));
const Billing = lazy(() => import('@/pages/Billing'));
const Membership = lazy(() => import('@/pages/Membership'));
const Verify = lazy(() => import('@/pages/Verify'));

export default function App() {
  return (
    <Layout>
      <Suspense fallback={<div className='p-6 text-gray-600'>Loading…</div>}>
        <Routes>
          {/* Public routes */}
          <Route index element={<Home />} />
          <Route path="signin" element={<SignIn />} />
          <Route path="signup" element={<SignUp />} />
          <Route path="verify" element={<Verify />} />

          {/* Member routes */}
          <Route element={<RoleProtectedRoute roles={['member', 'agent', 'admin']} />}>
            <Route path="portal" element={<MemberPortal />} />
            <Route path="billing" element={<Billing />} />
            <Route path="profile" element={<Profile />} />
            <Route path="membership" element={<Membership />} />
          </Route>

          {/* Agent routes */}
          <Route element={<RoleProtectedRoute roles={['agent', 'admin']} />}>
            <Route path="agent" element={<AgentTools />} />
          </Route>

          {/* Admin routes */}
          <Route element={<RoleProtectedRoute roles={['admin']} />}>
            <Route path="admin" element={<Admin />} />
          </Route>

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Suspense>
    </Layout>
  );
}
