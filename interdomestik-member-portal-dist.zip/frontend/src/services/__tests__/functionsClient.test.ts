import { describe, it, expect } from 'vitest';
import { callFn } from '../functionsClient';
import { mockCallable, getCallable } from '@/tests/mocks/firebaseFunctions';

describe('functionsClient', () => {
  it('should call the specified function with the correct name', async () => {
    const functionName = 'myTestFunction';
    const payload = { foo: 'bar' };
    const expectedResponse = { data: { result: 'success' } };

    const mock = mockCallable(functionName, { resolve: expectedResponse });

    const fn = callFn<typeof payload, typeof expectedResponse>(functionName);
    const result = await fn(payload);

    expect(getCallable(functionName)).toBe(mock);
    expect(result).toEqual(expectedResponse);
  });
});
