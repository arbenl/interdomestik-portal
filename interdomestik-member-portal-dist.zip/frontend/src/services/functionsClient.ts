import { httpsCallable } from 'firebase/functions';
import { functions } from '@/firebase';

// Known callable names in the app; extend as needed:
export type CallableMap = {
  updateProfile: { input: { name?: string; phone?: string, region?: string }; output: { ok: boolean } };
  createPaymentIntent: { input: { amount: number; currency: string, donateCents?: number, couponCode?: string, description?: string }; output: { clientSecret: string } };
  upsertProfile: { input: { name: string, phone: string, region: string }, output: { ok: boolean } },
  getCardToken: { input: { uid: string }, output: { token: string } },
  setAutoRenew: { input: { autoRenew: boolean }, output: { ok: boolean } },
  resendMembershipCard: { input: { uid?: string, year?: number }, output: { ok: boolean } },
};

export async function callFn<K extends keyof CallableMap>(
  name: K,
  payload: CallableMap[K]['input']
): Promise<CallableMap[K]['output']> {
  const fn = httpsCallable<CallableMap[K]['input'], CallableMap[K]['output']>(functions, name as string);
  const { data } = await fn(payload);
  return data;
}