import { describe, it, expect, vi } from 'vitest';
import { renderHookWithProviders, waitFor } from '@/test-utils';
import { useEvents } from '../useEvents';
import { getDocs } from 'firebase/firestore';
import { mockQuerySnapshot } from '../../tests/mocks';

vi.mock('firebase/firestore', async () => {
  const actual = await vi.importActual('firebase/firestore');
  return {
    ...actual,
    getDocs: vi.fn().mockResolvedValue({
      docs: [
        { id: 'e1', data: () => ({ title: 'Welcome', startAt: { seconds: 1 }, location: 'PRISHTINA' }) },
      ],
    }),
  };
});

describe('useEvents', () => {
  it('returns events list', async () => {
    const { result } = renderHookWithProviders(() => useEvents(5));
    await waitFor(() => expect(result.current.isLoading).toBe(false));
    expect(result.current.data).toHaveLength(1);
  });

  it('handles empty list', async () => {
    vi.mocked(getDocs).mockResolvedValue(mockQuerySnapshot([]));
    const { result } = renderHookWithProviders(() => useEvents(5));
    await waitFor(() => expect(result.current.isLoading).toBe(false));
    expect(result.current.data).toEqual([]);
  });

  it('handles errors', async () => {
    const err = new Error('boom');
    vi.mocked(getDocs).mockRejectedValue(err);
    const { result } = renderHookWithProviders(() => useEvents(5));
    await waitFor(() => expect(result.current.isLoading).toBe(false));
    expect(result.current.error).toBe(err);
  });
});
