import { describe, it, expect, beforeEach } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useOfflineCard } from '../useOfflineCard';

interface JwtPayload {
  mno: string;
  iat: number;
  exp: number;
  ver: number;
  jti: string;
}

function makeToken(expSecondsFromNow: number): string {
  const header = { alg: 'HS265', typ: 'JWT', kid: 'v1' };
  const now = Math.floor(Date.now()/1000);
  const payload: JwtPayload = { mno: 'INT-2025-000001', iat: now, exp: now + expSecondsFromNow, ver: 1, jti: 'abc123' };
  const enc = (obj: Record<string, unknown>) => Buffer.from(JSON.stringify(obj)).toString('base64url');
  return `${enc(header)}.${enc(payload as unknown as Record<string, unknown>)}.sig`;
}

describe('useOfflineCard', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('opts in, caches, falls back, and clears', () => {
    const soonExpToken = makeToken(3 * 24 * 3600); // 3 days
    const validToken = makeToken(30 * 24 * 3600);

    // Initial state
    const { result, rerender } = renderHook((props) => useOfflineCard(props.live), {
      initialProps: { live: null as string | null },
    });
    expect(result.current.enabled).toBe(false);
    expect(result.current.token).toBe(null);

    // Enable and provide a token
    act(() => { result.current.setEnabled(true); });
    rerender({ live: soonExpToken });
    expect(result.current.token).toBe(soonExpToken);
    expect(result.current.nearExpiry).toBe(true);
    expect(localStorage.getItem('offline_card_token')).toBe(soonExpToken);

    // Fallback to cached token
    rerender({ live: null });
    expect(result.current.token).toBe(soonExpToken);

    // Provide a new valid token
    rerender({ live: validToken });
    expect(result.current.token).toBe(validToken);
    expect(result.current.nearExpiry).toBe(false);

    // Disable and clear cache
            act(() => { result.current.setEnabled(false); });
            rerender({ live: null });
            expect(localStorage.getItem('offline_card_token')).toBe(null);
            expect(result.current.token).toBe(null);  });
});