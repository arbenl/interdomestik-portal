import { describe, it, expect, vi } from 'vitest';
import { renderWithProviders, screen, userEvent, waitFor } from '@/test-utils';
import PaymentElementBox from '../../../components/payments/PaymentElementBox';
import { mockCallable, getCalls } from '@/tests/mocks/firebaseFunctions';
import { ToastProvider } from '@/components/ui/Toast';

// Stub the Stripe script loading
vi.stubGlobal('Stripe', () => ({
  elements: () => ({
    create: () => ({
      mount: vi.fn(),
    }),
  }),
  confirmPayment: vi.fn().mockResolvedValue({
    paymentIntent: { status: 'succeeded' },
  }),
}));

describe('PaymentElementBox confirm flow', () => {
  it('confirms payment and shows success', async () => {
    vi.stubEnv('VITE_STRIPE_PUBLISHABLE_KEY', 'pk_test_123');
    mockCallable('createPaymentIntent', { resolve: { data: { ok: true, clientSecret: 'cs_test_123' } } });

    renderWithProviders(
      <ToastProvider>
        <PaymentElementBox amountCents={2500} currency="EUR" />
      </ToastProvider>
    );

    // Click the button to initialize the payment element
    const startButton = screen.getByRole('button', { name: /Start Card Payment/i });
    await userEvent.click(startButton);

    // Wait for the client secret to be fetched and the confirm button to appear
    const confirmButton = await screen.findByRole('button', { name: /Confirm Payment/i });
    await userEvent.click(confirmButton);

    // Assert that the callable was invoked
    await waitFor(() => {
      expect(getCalls('createPaymentIntent')).toHaveLength(1);
    });

    // Assert that a success message is shown
    expect(await screen.findByText(/Payment succeeded/i)).toBeInTheDocument();
  });
});