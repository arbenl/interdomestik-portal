import { describe, it, expect, vi } from 'vitest';
import { renderWithProviders, screen } from '@/test-utils';
import { RoleProtectedRoute } from '@/routes/RoleProtectedRoute';
import { useAuth } from '@/context/AuthProvider';
import { Routes, Route } from 'react-router-dom';

import { mockUseAuth, makeMockUser } from '@/tests/mocks';

vi.mock('@/context/AuthProvider');

const TestComponent = () => <div>Protected Content</div>;

describe('RoleProtectedRoute', () => {
  it('renders children when user has the required role', () => {
    vi.mocked(useAuth).mockReturnValue(mockUseAuth({ isAdmin: true }));

    renderWithProviders(
      <Routes>
        <Route element={<RoleProtectedRoute roles={['admin']} />}>
          <Route path="/protected" element={<TestComponent />} />
        </Route>
      </Routes>,
      { route: '/protected' }
    );

    expect(screen.getByText('Protected Content')).toBeInTheDocument();
  });

  it('redirects when user does not have the required role', () => {
    vi.mocked(useAuth).mockReturnValue(mockUseAuth({ user: makeMockUser() }));

    renderWithProviders(
      <Routes>
        <Route element={<RoleProtectedRoute roles={['admin']} />}>
          <Route path="/protected" element={<TestComponent />} />
        </Route>
        <Route path="/portal" element={<div>Portal Page</div>} />
      </Routes>,
      { route: '/protected' }
    );

    expect(screen.queryByText('Protected Content')).not.toBeInTheDocument();
    expect(screen.getByText('Portal Page')).toBeInTheDocument();
  });
});