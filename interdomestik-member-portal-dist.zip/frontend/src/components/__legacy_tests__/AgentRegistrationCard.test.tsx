import { describe, it, expect, vi } from 'vitest';
import { renderWithProviders, screen, fireEvent, waitFor } from '@/test-utils';
import { mockCallable, getCalls } from '@/tests/mocks/firebaseFunctions';
import AgentRegistrationCard from '../AgentRegistrationCard';

describe('AgentRegistrationCard', () => {
  it('submits with valid data and calls onSuccess', async () => {
    const onSuccess = vi.fn();
    const onError = vi.fn();
    mockCallable('agentCreateMember', { resolve: { ok: true } });

    renderWithProviders(
      <AgentRegistrationCard allowedRegions={['PRISHTINA']} onSuccess={onSuccess} onError={onError} />,
    );
    fireEvent.change(screen.getByPlaceholderText(/Email/i), { target: { value: 'new@example.com' } });
    fireEvent.change(screen.getByPlaceholderText(/Full name/i), { target: { value: 'New User' } });
    fireEvent.change(screen.getByRole('combobox'), { target: { value: 'PRISHTINA' } });
    fireEvent.click(screen.getByRole('button', { name: /Register Member/i }));

    await waitFor(() => expect(onSuccess).toHaveBeenCalled());
    expect(getCalls('agentCreateMember')).toHaveLength(1);
    expect(getCalls('agentCreateMember')[0][0]).toMatchObject({
      email: 'new@example.com',
      name: 'New User',
      region: 'PRISHTINA',
    });
  });
});

