import { describe, it, expect, vi } from 'vitest';
import { renderWithProviders, screen, waitFor, fireEvent } from '@/test-utils';
import { makeMockUser, mockUseAuth } from '@/tests/mocks';
import Navbar from '../Navbar';
import { useAuth } from '@/context/AuthProvider';

vi.mock('@/context/AuthProvider');

describe('Navbar', () => {
  it('renders links and toggles user menu', async () => {
    vi.mocked(useAuth).mockReturnValue(
      mockUseAuth({
        user: makeMockUser({ displayName: 'Test User' }),
      })
    );

    renderWithProviders(<Navbar />);

    // Open menu
    const avatarBtn = screen.getByRole('button');
    fireEvent.click(avatarBtn);
    await waitFor(() => {
      expect(screen.getByText('History')).toBeInTheDocument();
    });
  });
});