import { describe, it, expect, vi } from 'vitest';
import { renderWithProviders, screen, fireEvent, waitFor } from '@/test-utils';
import { mockCallable, getCalls } from '@/tests/mocks/firebaseFunctions';
import ActivateMembershipModal from '../ActivateMembershipModal';

describe('ActivateMembershipModal', () => {
  it('submits and calls onSuccess', async () => {
    const onClose = vi.fn();
    const onSuccess = vi.fn();
    mockCallable('startMembership', { resolve: { ok: true } });

    renderWithProviders(
      <ActivateMembershipModal
        user={{ id: 'u1', email: 'member@example.com' }}
        onClose={onClose}
        onSuccess={onSuccess}
      />,
    );
    fireEvent.click(screen.getByRole('button', { name: /activate/i }));

    await waitFor(() => expect(onSuccess).toHaveBeenCalled());
    await waitFor(() => expect(onClose).toHaveBeenCalled());

    expect(getCalls('startMembership')).toHaveLength(1);
    expect(getCalls('startMembership')[0][0]).toMatchObject({ uid: 'u1', year: new Date().getFullYear() });
  });
});
