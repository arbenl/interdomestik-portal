import { describe, it, expect, vi } from 'vitest';
import { renderWithProviders, screen, fireEvent, waitFor } from '@/test-utils';
import AgentRegistrationCard from '../AgentRegistrationCard';

// TODO: It's better to mock the service layer, not the raw firebase SDK.
vi.mock('@/firebase', () => ({
  auth: {} as unknown,
  db: {} as unknown,
  functions: { _url: 'http://localhost:5001' } as unknown,
  httpsCallable: vi.fn(() => vi.fn().mockRejectedValue(new Error('Registration failed'))),
}));

describe('AgentRegistrationCard (error path)', () => {
  it('calls onError when callable rejects', async () => {
    const onSuccess = vi.fn();
    const onError = vi.fn();
    renderWithProviders(
      <AgentRegistrationCard allowedRegions={['PRISHTINA']} onSuccess={onSuccess} onError={onError} />,
    );
    fireEvent.change(screen.getByPlaceholderText(/Email/i), { target: { value: 'new@example.com' } });
    fireEvent.change(screen.getByPlaceholderText(/Full name/i), { target: { value: 'New User' } });
    fireEvent.change(screen.getByRole('combobox'), { target: { value: 'PRISHTINA' } });
    fireEvent.click(screen.getByRole('button', { name: /Register Member/i }));
    await waitFor(() => expect(onError).toHaveBeenCalled());
  });
});

