
import { screen } from '@testing-library/react';
import { renderWithProviders } from '@/test-utils';
import Navbar from './Navbar';
import { vi } from 'vitest';

vi.mock('@/context/AuthProvider', () => ({
  useAuth: () => ({ user: { displayName: 'Test User' } }),
}));

describe('Navbar', () => {
  it('renders key navigation links', () => {
    renderWithProviders(<Navbar />);
    expect(screen.getByRole('link', { name: /Home/i })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /Portal/i })).toBeInTheDocument();
    expect(screen.getByText(/Hi, Test User/i)).toBeInTheDocument();
  });
});
