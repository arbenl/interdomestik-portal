import type { FirestoreDataConverter, QueryDocumentSnapshot, DocumentData } from 'firebase/firestore';
import type { EventItem, MonthlyReport, AuditLog } from '@/types';

function toFirestoreWithoutId<T extends { id?: unknown }>(modelObject: T): DocumentData {
  const data: Record<string, unknown> = { ...modelObject };
  // Avoid storing local id field on documents
  delete (data as { id?: unknown }).id;
  return data as DocumentData;
}

function addId<T extends { id?: string }>(snapshot: QueryDocumentSnapshot): T {
  const data = snapshot.data() as unknown as Omit<T, 'id'>;
  return { id: snapshot.id, ...(data as object) } as T;
}

export const eventConverter: FirestoreDataConverter<EventItem> = {
  toFirestore(modelObject: EventItem) {
    return toFirestoreWithoutId(modelObject);
  },
  fromFirestore(snapshot: QueryDocumentSnapshot) {
    return addId<EventItem>(snapshot);
  },
};

export const reportConverter: FirestoreDataConverter<MonthlyReport> = {
  toFirestore(modelObject: MonthlyReport) {
    return toFirestoreWithoutId(modelObject);
  },
  fromFirestore(snapshot: QueryDocumentSnapshot) {
    return addId<MonthlyReport>(snapshot);
  },
};

export const auditLogConverter: FirestoreDataConverter<AuditLog> = {
  toFirestore(modelObject: AuditLog) {
    return toFirestoreWithoutId(modelObject);
  },
  fromFirestore(snapshot: QueryDocumentSnapshot) {
    return addId<AuditLog>(snapshot);
  },
};
