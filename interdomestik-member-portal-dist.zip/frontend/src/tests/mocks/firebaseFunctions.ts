import { vi } from 'vitest';
import type { CallableMap } from '@/services/functionsClient';

const table: Partial<Record<keyof CallableMap, (payload: any) => any>> = {
  updateProfile: async (_p) => ({ ok: true }),
  createPaymentIntent: async (_p) => ({ clientSecret: 'cs_test_123' }),
  upsertProfile: async (_p) => ({ ok: true }),
};

export const mockCallFn = vi.fn(async <K extends keyof CallableMap>(
  name: K,
  payload: CallableMap[K]['input']
): Promise<CallableMap[K]['output']> => {
  const fn = table[name];
  if (!fn) {
    throw new Error(`No mock for callable: ${name}`);
  }
  return fn(payload) as CallableMap[K]['output'];
});

export function setCallableMock<K extends keyof CallableMap>(
  name: K,
  impl: (payload: CallableMap[K]['input']) => CallableMap[K]['output'] | Promise<CallableMap[K]['output']>
) {
  table[name] = impl;
}

export function resetCallableMocks() {
  mockCallFn.mockClear();
}