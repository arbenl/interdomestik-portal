import type { User, IdTokenResult, UserInfo } from 'firebase/auth';
import type { AuthContextValue } from '@/context/AuthProvider';
import { vi } from 'vitest';
import type { QuerySnapshot, QueryDocumentSnapshot } from 'firebase/firestore';

export function makeMockUser(partial: Partial<User> = {}): User {
  const providerData: UserInfo[] = [];
  const baseToken: IdTokenResult = {
    token: 'token',
    authTime: '',
    issuedAtTime: '',
    expirationTime: '',
    signInProvider: 'password',
    signInSecondFactor: null,
    claims: {},
  };

  const base: Partial<User> = {
    uid: 'u_test',
    email: 'test@example.com',
    displayName: 'Test User',
    emailVerified: true,
    isAnonymous: false,
    providerData,
    getIdToken: vi.fn().mockResolvedValue('token'),
    getIdTokenResult: vi.fn().mockResolvedValue(baseToken),
    reload: vi.fn().mockResolvedValue(void 0),
    toJSON: vi.fn().mockReturnValue({}),
  };
  return { ...(base as User), ...partial } as User;
}

export const mockUser = makeMockUser;

export function makeAuthCtx(overrides: Partial<AuthContextValue> = {}): AuthContextValue {
  return {
    user: makeMockUser(),
    loading: false,
    isAdmin: false,
    isAgent: false,
    allowedRegions: [],
    ...overrides,
  };
}

export function mockUseAuth(ctx?: Partial<AuthContextValue>) {
  const value = makeAuthCtx(ctx);
  return value;
}

export function mockQuerySnapshot<T extends object>(docs: Array<{ id: string; data: T }>) {
  const snap = {
    docs: docs.map(d => ({
      id: d.id,
      data: () => d.data,
    })) as unknown as Array<QueryDocumentSnapshot<T>>,
    size: docs.length,
    empty: docs.length === 0,
    forEach: (cb: (doc: QueryDocumentSnapshot<T>) => void) => {
      (snap.docs as Array<QueryDocumentSnapshot<T>>).forEach(cb)
    },
  } as unknown as QuerySnapshot<T>
  return snap
}
