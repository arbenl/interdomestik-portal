import type { User, IdTokenResult } from 'firebase/auth';

export function makeIdTokenResult(claims: Record<string, unknown> = {}): IdTokenResult {
  return {
    claims: {
      role: 'member',
      allowedRegions: [],
      ...claims,
    },
    token: 'test-token',
    authTime: '',
    expirationTime: '',
    issuedAtTime: '',
    signInProvider: null,
    signInSecondFactor: null,
  };
}

export function makeUser(overrides: Partial<User> & { claims?: Record<string, unknown> } = {}): User {
  const { claims, ...userOverrides } = overrides;
  return {
    uid: 'test-uid',
    email: 'test@example.com',
    displayName: 'Test User',
    emailVerified: true,
    isAnonymous: false,
    metadata: {},
    providerData: [],
    providerId: 'password',
    refreshToken: 'test-token',
    tenantId: null,
    delete: async () => {},
    getIdToken: async () => 'test-token',
    getIdTokenResult: async () => makeIdTokenResult(claims),
    reload: async () => {},
    toJSON: () => ({}),
    ...userOverrides,
  } as User;
}