import type { Profile } from '@/types';

export function makeProfile(overrides: Partial<Profile> = {}): Profile {
  return {
    id: 'test-profile-id',
    email: 'test@example.com',
    name: 'Test User',
    region: 'PRISHTINA',
    role: 'member',
    status: 'active',
    ...overrides,
  };
}
