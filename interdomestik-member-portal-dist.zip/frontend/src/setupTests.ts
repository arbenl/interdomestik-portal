import '@testing-library/jest-dom/vitest';
import 'whatwg-fetch';
import { vi, beforeEach } from 'vitest';

vi.mock('@/services/functionsClient', async () => {
  const actual = await vi.importActual<typeof import('@/services/functionsClient')>('@/services/functionsClient');
  const { mockCallFn } = await import('@/tests/mocks/firebaseFunctions');
  return {
    ...actual,
    callFn: mockCallFn,
  };
});

beforeEach(async () => {
  const { resetCallableMocks } = await import('@/tests/mocks/firebaseFunctions');
  resetCallableMocks();
});

