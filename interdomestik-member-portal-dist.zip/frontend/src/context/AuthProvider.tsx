import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { onIdTokenChanged, type User } from 'firebase/auth'
import { auth } from '@/firebase'

type Claims = { role?: 'admin'|'agent'|'member'; allowedRegions?: string[] }
type AuthCtx = {
  user: User | null
  loading: boolean
  isAdmin: boolean
  isAgent: boolean
  allowedRegions: string[]
}

export type AuthContextValue = AuthCtx;

const Ctx = createContext<AuthCtx | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User|null>(null)
  const [loading, setLoading] = useState(true)
  const [isAdmin, setIsAdmin] = useState(false)
  const [isAgent, setIsAgent] = useState(false)
  const [allowedRegions, setAllowedRegions] = useState<string[]>([])

  useEffect(() => {
    const unsub = onIdTokenChanged(auth, async (u) => {
      setLoading(true)
      try {
        setUser(u)
        if (!u) {
          setIsAdmin(false); setIsAgent(false); setAllowedRegions([])
          return
        }
        // Force a one-time refresh so newly-set custom claims appear immediately (esp. emulator)
        await u.getIdToken(true)
        const token = await u.getIdTokenResult()
        const claims = token.claims as Claims
        setIsAdmin(claims.role === 'admin')
        setIsAgent(claims.role === 'agent')
        setAllowedRegions(Array.isArray(claims.allowedRegions) ? claims.allowedRegions : [])
      } catch (err) {
        console.error('[AuthProvider] claim load failed', err)
        setIsAdmin(false); setIsAgent(false); setAllowedRegions([])
      } finally {
        setLoading(false)
      }
    })
    return () => unsub()
  }, [])

  const value = useMemo(() => ({ user, loading, isAdmin, isAgent, allowedRegions }), [user, loading, isAdmin, isAgent, allowedRegions])
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export function useAuth() {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
