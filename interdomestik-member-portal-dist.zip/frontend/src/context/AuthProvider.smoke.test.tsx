
import { render, screen } from '@testing-library/react';
import { AuthProvider, useAuth } from '@/context/AuthProvider';
import { describe, it, expect, vi } from 'vitest';
import type { User } from 'firebase/auth';

// Mock firebase auth
vi.mock('@/firebase', () => ({
  auth: {},
}));

vi.mock('firebase/auth', () => ({
  onIdTokenChanged: vi.fn((auth, callback) => {
    const mockUser = {
      uid: '123',
      displayName: 'Test User',
      getIdToken: async () => 'mock-token',
      getIdTokenResult: async () => ({
        token: 'mock-token',
        claims: { role: 'member' },
      }),
    } as unknown as User;
    callback(mockUser);
    return vi.fn(); // unsubscribe
  }),
}));

function TestComponent() {
  const { user, loading } = useAuth();
  if (loading) return <div>Loading...</div>;
  return <div>Welcome, {user?.displayName}</div>;
}

describe('AuthProvider', () => {
  it('provides user context to children after loading', async () => {
    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>
    );
    expect(await screen.findByText(/Welcome, Test User/i)).toBeInTheDocument();
  });
});
