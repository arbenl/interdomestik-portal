import { describe, it, expect } from 'vitest';
import { renderHook, waitFor, act } from '@testing-library/react';
import { AuthProvider, useAuth } from '../AuthProvider';
import { makeUser } from '@/tests/factories/user';
import type { User } from 'firebase/auth';
import { __setOnIdTokenChangedImpl } from '@/tests/__mocks__/firebase-auth.mock';

describe('AuthProvider', () => {
  it('should provide loading state and then null user', async () => {
    let callback: (user: User | null) => void = () => {};
    __setOnIdTokenChangedImpl((_auth: unknown, cb: (user: User | null) => void) => {
      callback = cb;
    });

    const { result } = renderHook(() => useAuth(), { wrapper: AuthProvider });
    expect(result.current.loading).toBe(true);

    act(() => {
      callback(null);
    });

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
      expect(result.current.user).toBeNull();
    });
  });

  it('should correctly identify an admin user from claims', async () => {
    const mockAdmin = makeUser({ claims: { role: 'admin' } });
    let callback: (user: User | null) => void = () => {};
    __setOnIdTokenChangedImpl((_auth: unknown, cb: (user: User | null) => void) => {
      callback = cb;
    });

    const { result } = renderHook(() => useAuth(), { wrapper: AuthProvider });

    act(() => {
      callback(mockAdmin);
    });

    await waitFor(() => {
      expect(result.current.isAdmin).toBe(true);
      expect(result.current.isAgent).toBe(false);
    });
  });
});