/// <reference types="vite/client" />

interface ImportMeta {
  readonly vitest: boolean
}