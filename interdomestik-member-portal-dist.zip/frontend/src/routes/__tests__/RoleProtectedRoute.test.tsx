import { describe, it, expect, vi } from 'vitest';
import { renderWithProviders, screen } from '@/test-utils';
import { RoleProtectedRoute } from '../RoleProtectedRoute';
import { useAuth } from '@/context/AuthProvider';
import { Routes, Route } from 'react-router-dom';
import { makeUser } from '@/tests/factories/user';

vi.mock('@/context/AuthProvider');

const MockPage = ({ text }: { text: string }) => <div>{text}</div>;

describe('RoleProtectedRoute', () => {
  it('redirects unauthenticated users to /signin', () => {
    vi.mocked(useAuth).mockReturnValue({ user: null, loading: false, isAdmin: false, isAgent: false, allowedRegions: [] });
    renderWithProviders(
      <Routes>
        <Route element={<RoleProtectedRoute roles={['member']} />}>
          <Route path="/" element={<MockPage text="Protected" />} />
        </Route>
        <Route path="/signin" element={<MockPage text="Signin" />} />
      </Routes>
    );
    expect(screen.getByText('Signin')).toBeInTheDocument();
  });

  it('shows loading state', () => {
    vi.mocked(useAuth).mockReturnValue({ user: null, loading: true, isAdmin: false, isAgent: false, allowedRegions: [] });
    renderWithProviders(
      <Routes>
        <Route element={<RoleProtectedRoute roles={['member']} />}>
          <Route path="/" element={<MockPage text="Protected" />} />
        </Route>
      </Routes>
    );
    expect(screen.getByText(/Checking permissions/i)).toBeInTheDocument();
  });

  it('allows admins to access admin routes', () => {
    vi.mocked(useAuth).mockReturnValue({
      user: makeUser({ claims: { role: 'admin' } }),
      loading: false,
      isAdmin: true,
      isAgent: false,
      allowedRegions: [],
    });
    renderWithProviders(
      <Routes>
        <Route element={<RoleProtectedRoute roles={['admin']} />}>
          <Route path="/" element={<MockPage text="Protected" />} />
        </Route>
      </Routes>
    );
    expect(screen.getByText('Protected')).toBeInTheDocument();
  });
});
