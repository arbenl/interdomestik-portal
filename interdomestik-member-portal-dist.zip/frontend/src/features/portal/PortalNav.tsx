export function PortalNav() {
  return (
    <nav>
      <ul>
        <li>Dashboard</li>
        <li>Profile</li>
        <li>Billing</li>
      </ul>
    </nav>
  );
}
