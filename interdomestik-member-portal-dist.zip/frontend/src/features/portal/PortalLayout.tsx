import { Outlet } from 'react-router-dom';
import { PortalNav } from './PortalNav';

export function PortalLayout() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-[220px_1fr] gap-4">
      <aside>
        <PortalNav />
      </aside>
      <main>
        <Outlet />
      </main>
    </div>
  );
}
