import { describe, it, expect, vi } from 'vitest';
import { renderWithProviders, screen, userEvent, waitFor } from '@/test-utils';
import { ProfilePanel } from '../ProfilePanel';
import { useMemberProfile } from '@/hooks/useMemberProfile';
import { useAuth } from '@/context/AuthProvider';
import { makeUser } from '@/tests/factories/user';
import { makeProfile } from '@/tests/factories/profile';
import { callFn } from '@/services/functionsClient';
import { makeHttpsCallableMock } from '@/tests/mocks/firebaseFunctions';

vi.mock('@/hooks/useMemberProfile');
vi.mock('@/context/AuthProvider');
vi.mock('@/services/functionsClient');

describe('ProfilePanel', () => {
  it('should display user profile information', () => {
    vi.mocked(useAuth).mockReturnValue({ user: makeUser(), loading: false, isAdmin: false, isAgent: false, allowedRegions: [] });
    vi.mocked(useMemberProfile).mockReturnValue({
      data: makeProfile({ name: 'John Doe' }),
      isLoading: false,
      error: null,
      isError: false,
      isPending: false,
      isLoadingError: false,
      isRefetchError: false,
      isSuccess: true,
      status: 'success',
      refetch: vi.fn(),
      isPlaceholderData: false,
      dataUpdatedAt: 0,
      errorUpdatedAt: 0,
      failureCount: 0,
      failureReason: null,
      errorUpdateCount: 0,
      isFetched: true,
      isFetchedAfterMount: true,
      isFetching: false,
      isInitialLoading: false,
      isPaused: false,
      isRefetching: false,
      isStale: false,
      isEnabled: true,
      fetchStatus: 'idle',
      promise: Promise.resolve(makeProfile()),
    });

    renderWithProviders(<ProfilePanel />);

    expect(screen.getByText('John Doe')).toBeInTheDocument();
  });

  it('should allow updating the profile', async () => {
    const mockUpdateProfile = makeHttpsCallableMock(async () => ({ ok: true }));
    vi.mocked(callFn).mockReturnValue(mockUpdateProfile);
    vi.mocked(useAuth).mockReturnValue({ user: makeUser(), loading: false, isAdmin: false, isAgent: false, allowedRegions: [] });
    vi.mocked(useMemberProfile).mockReturnValue({
      data: makeProfile(),
      isLoading: false,
      error: null,
      isError: false,
      isPending: false,
      isLoadingError: false,
      isRefetchError: false,
      isSuccess: true,
      status: 'success',
      refetch: vi.fn(),
      isPlaceholderData: false,
      dataUpdatedAt: 0,
      errorUpdatedAt: 0,
      failureCount: 0,
      failureReason: null,
      errorUpdateCount: 0,
      isFetched: true,
      isFetchedAfterMount: true,
      isFetching: false,
      isInitialLoading: false,
      isPaused: false,
      isRefetching: false,
      isStale: false,
      isEnabled: true,
      fetchStatus: 'idle',
      promise: Promise.resolve(makeProfile()),
    });

    renderWithProviders(<ProfilePanel />);

    const nameInput = screen.getByLabelText(/name/i);
    await userEvent.clear(nameInput);
    await userEvent.type(nameInput, 'Jane Doe');
    
    const saveButton = screen.getByRole('button', { name: /save/i });
    await userEvent.click(saveButton);

    await waitFor(() => {
      expect(mockUpdateProfile).toHaveBeenCalledWith(expect.objectContaining({ name: 'Jane Doe' }));
    });
  });
});