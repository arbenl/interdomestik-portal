
import { screen } from '@testing-library/react';
import { renderWithProviders } from '@/test-utils';
import { PortalLayout } from './PortalLayout';
import { describe, it, expect } from 'vitest';

vi.mock('./PortalNav', () => ({
  PortalNav: () => <div>Portal Navigation</div>,
}));

describe('PortalLayout', () => {
  it('renders the portal navigation and a child outlet', () => {
    renderWithProviders(<PortalLayout />);
    expect(screen.getByText('Portal Navigation')).toBeInTheDocument();
  });
});
