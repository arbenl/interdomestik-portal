export function BulkImportPanel() {
  return <div>Bulk Import</div>;
}