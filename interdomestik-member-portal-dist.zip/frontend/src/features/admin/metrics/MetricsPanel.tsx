export function MetricsPanel() {
  return <div>Metrics</div>;
}