export function MemberSearchPanel() {
  return <div>Member Search</div>;
}