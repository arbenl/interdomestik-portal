import { vi } from 'vitest';
import { renderWithProviders, screen, fireEvent, within } from '@/test-utils';
import Admin from '../Admin';
import { mockUser } from '../../tests/mocks';
import { useAuth } from '@/context/AuthProvider';

vi.mock('@/context/AuthProvider');

describe('Admin Coupons panel', () => {
  it('renders and saves coupon', async () => {
    vi.mocked(useAuth).mockReturnValue({
      user: mockUser(),
      loading: false,
      isAdmin: true,
      isAgent: false,
      allowedRegions: ['PRISHTINA'],
    });
    renderWithProviders(<Admin />);
    const panel = await screen.findByText(/Coupons/i);
    const code = within(panel.parentElement as HTMLElement).getByLabelText(/Code/i) as HTMLInputElement;
    fireEvent.change(code, { target: { value: 'WELCOME' } });
    fireEvent.click(within(panel.parentElement as HTMLElement).getByRole('button', { name: /Save Coupon/i }));
    expect(screen.getByText(/Coupons/i)).toBeInTheDocument();
  });
});
