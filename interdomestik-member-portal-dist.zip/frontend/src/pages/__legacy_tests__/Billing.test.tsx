import { renderWithProviders, screen } from '@/test-utils';
import { describe, it, expect, vi, type Mock } from 'vitest';
import Billing from '../Billing';
import { mockUser } from '../../tests/mocks';
import { useAuth } from '@/context/AuthProvider';
import { useMemberProfile } from '@/hooks/useMemberProfile';
import { useInvoices } from '@/hooks/useInvoices';

vi.mock('@/context/AuthProvider');
vi.mock('@/hooks/useMemberProfile');
vi.mock('@/hooks/useInvoices');

describe('Billing page', () => {
  it('renders headings and actions', async () => {
    vi.mocked(useAuth).mockReturnValue({ user: mockUser(), loading: false, isAdmin: false, isAgent: false, allowedRegions: [] });
    (useMemberProfile as Mock).mockReturnValue({ data: { name: 'Test User' }, isLoading: false });
    (useInvoices as Mock).mockReturnValue({ data: [], isLoading: false });
    renderWithProviders(<Billing />);
    expect(screen.getByText('Billing')).toBeInTheDocument();
  });
});
