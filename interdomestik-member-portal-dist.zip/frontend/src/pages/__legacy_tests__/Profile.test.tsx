import { describe, it, expect, vi, type Mock } from 'vitest';
import { renderWithProviders, screen, fireEvent, waitFor } from '@/test-utils';
import Profile from '../Profile';
import { mockUser } from '../../tests/mocks';
import { useAuth } from '@/context/AuthProvider';
import { useMemberProfile } from '@/hooks/useMemberProfile';

vi.mock('@/context/AuthProvider');
vi.mock('@/hooks/useMemberProfile');

describe('Profile page', () => {
  it('updates profile successfully', async () => {
    vi.mocked(useAuth).mockReturnValue({ user: mockUser(), loading: false, isAdmin: false, isAgent: false, allowedRegions: [] });
    const mutate = vi.fn();
    (useMemberProfile as Mock).mockReturnValue({ data: { name: 'User One' }, isLoading: false, error: null, mutate });
    renderWithProviders(<Profile />);
    const nameInput = screen.getByLabelText(/Name/i);
    fireEvent.change(nameInput, { target: { value: 'User One Updated' } });
    fireEvent.click(screen.getByRole('button', { name: /Update Profile/i }));
    await waitFor(() => {
      expect(mutate).toHaveBeenCalledWith({ name: 'User One Updated' });
    });
  });
});