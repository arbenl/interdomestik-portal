import { renderWithProviders } from '@/test-utils';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import Admin from '../Admin';
import { mockUser } from '../../tests/mocks';
import { useAuth } from '@/context/AuthProvider';

vi.mock('@/context/AuthProvider');

describe('Admin Card Keys panel', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(useAuth).mockReturnValue({
      user: mockUser(),
      loading: false,
      isAdmin: true,
      isAgent: false,
      allowedRegions: ['PRISHTINA'],
    });
  });

  it('shows active kid and allows revoke by jti', async () => {
    renderWithProviders(<Admin />);
    expect(true).toBe(true); // Placeholder assertion
  });
});
