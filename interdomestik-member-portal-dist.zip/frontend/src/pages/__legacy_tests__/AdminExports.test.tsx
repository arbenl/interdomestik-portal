import { renderWithProviders } from '@/test-utils';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import Admin from '../Admin';
import { mockUser } from '../../tests/mocks';
import { useAuth } from '@/context/AuthProvider';

vi.mock('@/context/AuthProvider');

describe('Admin Exports panel', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(useAuth).mockReturnValue({
      user: mockUser(),
      loading: false,
      isAdmin: true,
      isAgent: false,
      allowedRegions: ['PRISHTINA'],
    });
  });

  it('renders exports list with actions and disables start when running', async () => {
    renderWithProviders(<Admin />);
    expect(true).toBe(true); // Placeholder assertion
  });

  it('toggles Show more/Show less and resubscribes', async () => {
    renderWithProviders(<Admin />);
    expect(true).toBe(true); // Placeholder assertion
  });

  it('starts export and shows success toast', async () => {
    renderWithProviders(<Admin />);
    expect(true).toBe(true); // Placeholder assertion
  });
});