import { renderWithProviders, screen, waitFor } from '@/test-utils';
import { vi, type Mock } from 'vitest';
import Admin from '../Admin';
import { useAuth } from '@/context/AuthProvider';
import { useReports } from '@/hooks/useReports';

vi.mock('@/context/AuthProvider');
vi.mock('@/hooks/useReports');

describe('Admin Reports panel', () => {
  it('renders monthly report rows with CSV link', async () => {
    (useAuth as Mock).mockReturnValue({ isAdmin: true, isAgent: false, allowedRegions: ['PRISHTINA'], loading: false });
    (useReports as Mock).mockReturnValue({ data: [{ id: '2025-09', rowCount: 5 }], isLoading: false, error: null });

    renderWithProviders(<Admin />);

    await waitFor(() => {
      expect(screen.getByText('Monthly Reports')).toBeInTheDocument();
    });
    expect(screen.getByText('2025-09')).toBeInTheDocument();
    expect(screen.getByText('5')).toBeInTheDocument();
  });
});