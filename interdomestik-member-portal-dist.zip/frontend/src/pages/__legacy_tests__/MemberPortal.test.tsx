import { describe, it, expect, vi } from 'vitest';
import { renderWithProviders, screen, waitFor } from '@/test-utils';
import MemberPortal from '../MemberPortal';
import { mockUser } from '../../tests/mocks';
import { useAuth } from '@/context/AuthProvider';

vi.mock('@/context/AuthProvider');

describe('MemberPortal', () => {
  it('asks unauthenticated users to sign in', () => {
    vi.mocked(useAuth).mockReturnValue({ user: null, loading: false, isAdmin: false, isAgent: false, allowedRegions: [] });
    renderWithProviders(<MemberPortal />);
    expect(screen.getByText(/Please sign in/i)).toBeInTheDocument();
  });

  it('renders main portal sections for signed-in user', async () => {
    vi.mocked(useAuth).mockReturnValue({
      user: mockUser({ displayName: 'Member One' }),
      loading: false,
      isAdmin: false,
      isAgent: false,
      allowedRegions: [],
    });
    renderWithProviders(<MemberPortal />);
    await waitFor(() => expect(screen.getByText(/Welcome, Member One/i)).toBeInTheDocument());
  });
});
