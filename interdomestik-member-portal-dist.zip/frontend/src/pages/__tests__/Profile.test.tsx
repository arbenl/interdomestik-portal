
import { screen, waitFor } from '@testing-library/react';
import { renderWithProviders, userEvent } from '@/test-utils';
import Profile from '../Profile';
import { describe, it, expect, vi } from 'vitest';
import { useMemberProfile } from '@/hooks/useMemberProfile';
import { setCallableMock } from '@/tests/mocks/firebaseFunctions';
import { callFn } from '@/services/functionsClient';

// Mock dependencies
vi.mock('@/hooks/useMemberProfile');
vi.mock('@/context/AuthProvider', () => ({
  useAuth: () => ({ user: { uid: 'test-uid', email: 'test@example.com' } }),
}));
vi.mock('@/components/ui/useToast', () => ({
  useToast: () => ({ push: vi.fn() }),
}));

const mockProfile = {
  name: 'Test User',
  email: 'test@example.com',
  region: 'PRISHTINA',
  phone: '123456789',
};

describe('Profile Page', () => {
  it('renders current profile data', () => {
    (useMemberProfile as vi.Mock).mockReturnValue({
      data: mockProfile,
      isLoading: false,
      error: null,
    });

    renderWithProviders(<Profile />);

    expect(screen.getByLabelText(/name/i)).toHaveValue(mockProfile.name);
    expect(screen.getByDisplayValue(mockProfile.email)).toBeInTheDocument();
    expect(screen.getByLabelText(/phone/i)).toHaveValue(mockProfile.phone);
  });

  it('updates name successfully', async () => {
    (useMemberProfile as vi.Mock).mockReturnValue({
      data: mockProfile,
      isLoading: false,
    });

    renderWithProviders(<Profile />);
    const nameInput = screen.getByLabelText(/name/i);
    await userEvent.clear(nameInput);
    await userEvent.type(nameInput, 'Updated Name');
    await userEvent.click(screen.getByRole('button', { name: /update profile/i }));

    await waitFor(() => {
      expect(callFn).toHaveBeenCalledWith('upsertProfile', expect.objectContaining({
        name: 'Updated Name',
      }));
    });
    expect(await screen.findByText(/Profile updated successfully!/i)).toBeInTheDocument();
  });

  it('shows error on update failure', async () => {
    setCallableMock('upsertProfile', () => Promise.reject(new Error('Update failed')));
    (useMemberProfile as vi.Mock).mockReturnValue({
      data: mockProfile,
      isLoading: false,
    });

    renderWithProviders(<Profile />);
    await userEvent.click(screen.getByRole('button', { name: /update profile/i }));

    expect(await screen.findByText(/Update failed/i)).toBeInTheDocument();
  });
});
