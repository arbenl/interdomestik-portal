
import { screen } from '@testing-library/react';
import { renderWithProviders } from '@/test-utils';
import MemberPortal from './MemberPortal';
import { describe, it, expect, vi } from 'vitest';

vi.mock('@/context/AuthProvider', () => ({
  useAuth: () => ({ user: { uid: '123' } }),
}));

vi.mock('../features/portal/ProfilePanel', () => ({
  ProfilePanel: () => <div>Profile Panel Mock</div>
}));
vi.mock('../features/portal/MembershipPanel', () => ({
  MembershipPanel: () => <div>Membership Panel Mock</div>
}));
vi.mock('../features/portal/BillingPanel', () => ({
  BillingPanel: () => <div>Billing Panel Mock</div>
}));


describe('MemberPortal Page', () => {
  it('renders key panels when user is logged in', async () => {
    renderWithProviders(<MemberPortal />);
    expect(await screen.findByText('Profile Panel Mock')).toBeInTheDocument();
    expect(await screen.findByText('Membership Panel Mock')).toBeInTheDocument();
    expect(await screen.findByText('Billing Panel Mock')).toBeInTheDocument();
  });
});
