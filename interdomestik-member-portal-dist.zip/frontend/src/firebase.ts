import { initializeApp } from 'firebase/app';
import { getAuth, connectAuthEmulator } from 'firebase/auth';
import { getFirestore, connectFirestoreEmulator } from 'firebase/firestore';
import { getFunctions, connectFunctionsEmulator } from 'firebase/functions';

const app = initializeApp({
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || 'dev-api-key',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || 'localhost',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || 'demo-project',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || '1:demo:web:demo',
});

export const auth = getAuth(app);
export const db = getFirestore(app);
export const functions = getFunctions(app, 'europe-west1');

const isTest = process.env.VITEST === '1' || import.meta.vitest;
const isLocal =
  !isTest &&
  (import.meta.env?.DEV ||
    (typeof window !== 'undefined' && ['localhost', '127.0.0.1', '::1'].includes(window.location.hostname)));

if (isLocal) {
  console.log('[firebase] Connecting to emulators');
  try {
    connectAuthEmulator(auth, 'http://127.0.0.1:9099', { disableWarnings: true });
  } catch {
    /* ignore */
  }
  try {
    connectFirestoreEmulator(db, '127.0.0.1', 8080);
  } catch {
    /* ignore */
  }
  try {
    connectFunctionsEmulator(functions, '127.0.0.1', 5001);
  } catch {
    /* ignore */
  }
}