// This file is intentionally left blank.
// It's used for type declarations that are global to the project.
// For example, you can declare global types for CSS modules here.