/** @type {import('tailwindcss').Config} */
export default {
  // v4 doesn’t require content globs.
  theme: { extend: {} },
  plugins: [],
}