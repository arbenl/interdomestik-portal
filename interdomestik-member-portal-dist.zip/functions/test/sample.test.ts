import { expect } from 'chai';

describe('Sample Test', () => {
  it('should return true', () => {
    expect(true).to.be.true;
  });
});
