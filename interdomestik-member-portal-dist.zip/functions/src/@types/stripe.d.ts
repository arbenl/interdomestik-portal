declare module 'stripe' {
  const Stripe: any;
  export = Stripe;
  export default Stripe;
}

