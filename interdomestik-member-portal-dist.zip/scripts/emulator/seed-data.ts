export const ADMIN_EMAIL = 'admin@example.com';
export const ADMIN_PASSWORD = 'Passw0rd!';
